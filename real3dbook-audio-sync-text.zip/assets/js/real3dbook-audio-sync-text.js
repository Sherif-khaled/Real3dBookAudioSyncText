

function createElements (pageContent,attr) {

  let btn = '<button class="audiobtn" id="'+ attr['button_id'] +'">\n' +
    '    <svg class="play" width="50" height="50" viewBox="0 0 85 100">\n' +
    '    \t<path fill="currentColor" d="M81 44.6c5 3 5 7.8 0 10.8L9 98.7c-5 3-9 .7-9-5V6.3c0-5.7 4-8 9-5l72 43.3z">\n' +
    '    \t\t<title>PLAY</title>\n' +
    '    \t</path>\n' +
    '    </svg>\n' +
    '    <svg class="pause" width="50" height="50" viewBox="0 0 60 100"><path fill="currentColor" d="M0 8c0-5 3-8 8-8s9 3 9 8v84c0 5-4 8-9 8s-8-3-8-8V8zm43 0c0-5 3-8 8-8s8 3 8 8v84c0 5-3 8-8 8s-8-3-8-8V8z"><title>PAUSE</title></path></svg>\n' +
    '</button>';

  if(jQuery(pageContent).find("#" + attr['button_id'] +"").length === 0){
    jQuery(pageContent).append(btn);

  }

  let mediaPlayer = '<div class="mediaPlayer">\n' +
    '    <audio id="'+ attr['audio_id'] +'" src="' + attr['audio_file'] +'" controls></audio>\n' +
    '</div><br>';

  if(jQuery(pageContent).find("#" + attr['audio_id'] + "").length === 0){
    jQuery(pageContent).append(mediaPlayer);
  }

  let subtitles = '<div class="subtitle" id="'+ attr['subtitles_id'] +'"></div>\n';

  if(jQuery(pageContent).find("#" + attr['subtitles_id'] + "").length === 0){
    jQuery(pageContent).append(subtitles);
  }
}

function createJSBlock (pageContent,attr,data) {
  let block = '  <script>\n' +
    '        ( function(win, doc) {\n' +
    '            let audioPlayer = jQuery("#' + attr["audio_id"] + '"' + ');\n' +
    '            let subtitles   = jQuery("#' + attr["subtitles_id"] +'"' + ');\n' +
    '            let playButton  = jQuery("#' + attr["button_id"] + '"' + ');\n' +
    '\n' +
    '            let syncData = '+ JSON.stringify(data) +';\n' +
    '\n' +
    '            resetContent();\n' +
    '            createSubtitle();\n' +
    '\n' +
    '            jQuery(\'canvas\').on(\'click\', function(e) {\n' +
    '                if (e.target !== this)\n' +
    '                    return;\n' +
    '\n' +
    '                if(audioPlayer !== null){\n' +
    '\n' +
    '                   audioPlayer[0].play();\n' +
    '\n' +
    '                }\n' +
    '            });\n' +
    '\n' +
    '\n' +
    '            jQuery(\'.flipbook-righ-arrow\').on(\'click\',function () {\n' +
    '         \n' +
    '                resetContent();\n' +
    '\n' +
    '\n' +
    '            });\n' +
    '            jQuery(\'.flipbook-lef-arrow\').on(\'click\',function () {\n' +
    '         \n' +
    '                resetContent();\n' +
    '\n' +
    '\n' +
    '            });\n' +
    '\n' +
    '\n' +
    '\n' +
    '            jQuery("span[title=\'Close\']").on(\'click\',function () {\n' +
    '                audioPlayer[0].pause();\n' +
    '            });\n' +
    '\n' +
    '            function createSubtitle()\n' +
    '            {\n' +
    '                let element;\n' +
    '                for (let i = 0; i < syncData.length; i++) {\n' +
    '                    element = "<span id=\''+ attr["subtitles_id"] +'_c_" + i +"\'>" + syncData[i].text +"</span>";\n' +
    '                    subtitles.append(element);\n' +
    '                }\n' +
    '\n' +
    '            }\n' +
    '\n' +
    '            playButton.on(\'click\', function () {\n' +
    '            \tif(audioPlayer[0].duration > 0 && !audioPlayer[0].paused){\n' +
    '                    audioPlayer[0].pause();\n' +
    '            \t}else{\n' +
    '                    audioPlayer[0].play();\n' +
    '            \t}\n' +
    '            });\n' +
    '\n' +
    '            audioPlayer.on(\'loadeddat\', function()\n' +
    '            {\n' +
    '\n' +
    '                return new Promise(function(resolve, reject) {\n' +
    '                    let promise = audioPlayer[0].play();\n' +
    '\n' +
    '                    promise.then(function(data) {\n' +
    '                        data = audioPlayer[0].play();\n' +
    '                        resolve(data);\n' +
    '                    }, function(error) {\n' +
    '    \n' +
    '                        doc.on(\'click\', function () {\n' +
    '                           audioPlayer[0].play();\n' +
    '                        }, { once: true });\n' +
    '                    });\n' +
    '                });\n' +
    '\n' +
    '            });\n' +
    '    \n' +
    '            audioPlayer.on(\'pause\',function(){\n' +
    '                playButton.removeClass(\'is-playing\');\n' +
    '            });\n' +
    '    \n' +
    '            audioPlayer.on(\'aborted\',function(){\n' +
    '                playButton.removeClass(\'is-playing\');\n' +
    '            });\n' +
    '    \n' +
    '            audioPlayer.on(\'play\',function(){\n' +
    '                playButton.addClass(\'is-playing\');\n' +
    '    \n' +
    '            });\n' +
    '\n' +
    '            \n' +
    '            audioPlayer.on("timeupdate", function(e){\n' +
    '                syncData.forEach(function(element,index, array){\n' +
    '                    syncData.filter(function(){return true;});\n' +
    '\n' +
    '                    if( audioPlayer[0].currentTime >= element.start && audioPlayer[0].currentTime <= element.end )\n' +
    '                        subtitles.find("#" + jQuery(subtitles).attr("id") +"_c_" + index).css(\'background-color\',\'yellow\');\n' +
    '                });\n' +
    '            });\n' +
    '    \n' +
    '            function resetContent() {\n' +
    '                if (typeof audioPlayer[0] !== \'undefined\'){\n' +
    '                    if(audioPlayer[0].length !== 0){\n' +
    '    \n' +
    '                        audioPlayer[0].pause();\n' +
    '                        playButton.removeClass(\'is-playing\');\n' +
    '                        audioPlayer[0].currentTime = 0;\n' +
    '                \n' +
    '                    }\n' +
    '                }\n' +
    '                audioPlayer.unbind();\n' +
    '                playButton.unbind();\n' +
    '        \n' +
    '                jQuery(\'canvas\').unbind();\n' +
    '        \n' +
    '                subtitles.find("span").remove();\n' +
    '        \n' +
    '                syncData.filter(function(){return true;});\n' +
    '        \n' +
    '            }\n' +
    '\n' +
    '\n' +
    '        }(window, document));\n' +
    '\n' +
    '\n' +
    '\n' +
    '        </script>\n' +
    '<style>\n' +
    '\n' +
      ' .audiobtn {\n' +
      'margin: 20px;\n' +
      '}\n' +
    '    .pause {\n' +
    '        display: none;\n' +
    '    }\n' +
    '\n' +
    '    .is-playing .play {\n' +
    '        display: none;\n' +
    '    }\n' +
    '\n' +
    '    .is-playing .pause {\n' +
    '        display: block;\n' +
    '    }\n' +
    '    .mediaPlayer{\n' +
    '        display: none;\n' +
    '    }\n' +
      ' .subtitle span {\n' +
      'font-size: 30px; ' +
      'font-family: "Cairo", "Sans-serif"; ' +
      'font-weight:bold;\n' +
      'padding-left: 15px;\n' +
      '}\n' +
    '</style>\n';

  jQuery(pageContent).append(block);

}
function init (point, attr, data) {
  let leftPage = jQuery('.htmlLayer').find(".L");
  let rightPage = jQuery('.htmlLayer').find(".R");

  let leftPageScripts = jQuery(leftPage).find(point).find('script').length;
  let rightPageScripts = jQuery(rightPage).find(point).find('script').length;

  if(leftPageScripts !== 0){
    let checkElmnt = jQuery(leftPage).find(point).find('button').length;
    if(checkElmnt === 0){
      if(point[1] === 'undefined'){
        console.log('fire');
        createElements(point[0],attr);
        createJSBlock(point[0],attr,data);
      }else {

        createElements(point[1],attr);
        createJSBlock(point[1],attr,data);
      }

    }
  }

  if(rightPageScripts !== 0){

    let checkElmnt = jQuery(rightPage).find(point).find('button').length;
    if(checkElmnt === 0){
      createElements(point[0],attr);
      createJSBlock(point[0],attr,data);

    }
  }

}



